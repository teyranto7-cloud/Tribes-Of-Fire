#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
exec ./TribesOfFireServer.x86_64 --headless -- --server "$@"
